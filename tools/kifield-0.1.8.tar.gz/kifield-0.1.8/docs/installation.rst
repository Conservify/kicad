============
Installation
============

At the command line::

    $ easy_install kifield

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv kifield
    $ pip install kifield
